Hearth Admin 0.4.1

Server and all clients need the same version. Open F8 for RU / EN. Web tools require Hearth. Source: https://github.com/serya1c/valheim-server/tree/main/game-mods/ValheimAdminRu
